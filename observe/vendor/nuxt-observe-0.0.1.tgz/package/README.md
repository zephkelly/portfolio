# nuxt-observe

[![npm version][npm-version-src]][npm-version-href]
[![npm downloads][npm-downloads-src]][npm-downloads-href]
[![License][license-src]][license-href]
[![Nuxt][nuxt-src]][nuxt-href]

Self-hosted observability + service-registry dashboard module for Nuxt.

- [✨ &nbsp;Release Notes](/CHANGELOG.md)

## Features

- 📊 &nbsp;Self-hosted observability dashboard, mounted at a configurable prefix
- 🩺 &nbsp;Health endpoint under `/api/observe`
- 🧩 &nbsp;Zero-config: works out of the box, tune via the `observe` key or `nuxt-observe.config.ts`

## Quick Setup

Install the module in your Nuxt application:

```bash
npx nuxt module add nuxt-observe
```

Then open the dashboard at `/observe` (change the mount path via `observe.prefix`).

## Documentation

Full documentation lives in [`docs/`](./docs) and is built with VitePress:

```bash
# Start the docs dev server
pnpm docs:dev

# Build the static docs site
pnpm docs:build

# Preview the built site
pnpm docs:preview
```

## Contribution

<details>
  <summary>Local development</summary>

  ```bash
  # Install dependencies
  pnpm install

  # Generate type stubs
  pnpm dev:prepare

  # Develop with the playground
  pnpm dev

  # Build the playground
  pnpm dev:build

  # Run ESLint
  pnpm lint

  # Run the fast unit suite (Vitest, node env)
  pnpm test
  pnpm test:watch

  # Run the Nuxt integration suite (boots the fixture app, exercises the endpoints)
  pnpm test:nuxt

  # Run the Playwright dashboard e2e suite (needs `npx playwright install chromium` once)
  pnpm test:e2e

  # Release new version
  pnpm release
  ```

</details>


<!-- Badges -->
[npm-version-src]: https://img.shields.io/npm/v/nuxt-observe/latest.svg?style=flat&colorA=020420&colorB=00DC82
[npm-version-href]: https://npmjs.com/package/nuxt-observe

[npm-downloads-src]: https://img.shields.io/npm/dm/nuxt-observe.svg?style=flat&colorA=020420&colorB=00DC82
[npm-downloads-href]: https://npm.chart.dev/nuxt-observe

[license-src]: https://img.shields.io/npm/l/nuxt-observe.svg?style=flat&colorA=020420&colorB=00DC82
[license-href]: https://npmjs.com/package/nuxt-observe

[nuxt-src]: https://img.shields.io/badge/Nuxt-020420?logo=nuxt
[nuxt-href]: https://nuxt.com
